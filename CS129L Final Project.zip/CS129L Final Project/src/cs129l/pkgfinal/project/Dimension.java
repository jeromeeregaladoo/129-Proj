/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs129l.pkgfinal.project;

/**
 *
 * @author Reymuel
 */
public class Dimension extends java.awt.Dimension {

    public Dimension(int height, int width) 
    {
        this.height = height;
        this.width = width;
    }
    
}
